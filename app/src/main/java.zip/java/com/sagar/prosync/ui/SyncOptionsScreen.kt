package com.sagar.prosync.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sagar.prosync.sync.FolderPicker
import com.sagar.prosync.sync.FolderStore
import com.sagar.prosync.sync.MediaScanner
import com.sagar.prosync.sync.UploadRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncOptionsScreen() {

    var syncPhotos by remember { mutableStateOf(true) }
    var syncVideos by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val folderStore = remember { FolderStore(context) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data ?: return@rememberLauncherForActivityResult
        FolderPicker.persistPermission(context, uri)
        folderStore.save(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Sync Options") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Text("Select what you want to sync", style = MaterialTheme.typography.titleMedium)

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = {
                FolderPicker.launch(launcher)
            }) {
                Text("Add Folder")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(
                    checked = syncPhotos,
                    onCheckedChange = { syncPhotos = it }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Photos")
            }

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(
                    checked = syncVideos,
                    onCheckedChange = { syncVideos = it }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Videos")
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    scope.launch {
                        val items = MediaScanner.scan(context, syncPhotos, syncVideos)
                        val repo = UploadRepository(context)

                        for (item in items) {
                            repo.upload(item)
                        }
                    }
                },
                enabled = syncPhotos || syncVideos
            ) {
                Text("Save & Start Sync")
            }
        }
    }
}
