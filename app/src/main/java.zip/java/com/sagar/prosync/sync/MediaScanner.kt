package com.sagar.prosync.sync

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class MediaItem(
    val uri: Uri,
    val relativePath: String,
    val size: Long,
    val isVideo: Boolean
)

object MediaScanner {

    /**
     * Entry point
     */
    fun scan(
        context: Context,
        uploadPhotos: Boolean,
        uploadVideos: Boolean
    ): List<MediaItem> {

        val selectedFolders = FolderStore(context)
            .getAll()
            .map { normalizeFolder(it) }
            .toSet()

        val results = mutableListOf<MediaItem>()

        if (uploadPhotos) {
            results += scanImages(context, selectedFolders)
        }

        if (uploadVideos) {
            results += scanVideos(context, selectedFolders)
        }

        return results
    }

    // ---------- Photos ----------

    private fun scanImages(
        context: Context,
        selectedFolders: Set<String>
    ): List<MediaItem> {
        return scanCommon(
            context = context,
            collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            isVideo = false,
            selectedFolders = selectedFolders
        )
    }

    // ---------- Videos ----------

    private fun scanVideos(
        context: Context,
        selectedFolders: Set<String>
    ): List<MediaItem> {
        return scanCommon(
            context = context,
            collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            isVideo = true,
            selectedFolders = selectedFolders
        )
    }

    // ---------- Core scanner ----------

    private fun scanCommon(
        context: Context,
        collection: Uri,
        isVideo: Boolean,
        selectedFolders: Set<String>
    ): List<MediaItem> {

        val items = mutableListOf<MediaItem>()

        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DISPLAY_NAME
        )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            null
        )?.use { cursor ->

            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val size = cursor.getLong(sizeCol)
                val relativeDir = cursor.getString(pathCol) ?: continue
                val name = cursor.getString(nameCol) ?: continue

                val normalizedPath = normalizeFolder(relativeDir)

                // 🔒 SAF folder filter
                if (!isUnderSelectedFolders(normalizedPath, selectedFolders)) {
                    continue
                }

                val contentUri = ContentUris.withAppendedId(collection, id)

                items += MediaItem(
                    uri = contentUri,
                    relativePath = "$relativeDir$name", // EXACT backend match
                    size = size,
                    isVideo = isVideo
                )
            }
        }

        return items
    }

    // ---------- Helpers ----------

    /**
     * Normalizes MediaStore folder paths:
     * "DCIM/Camera/" → "dcim/camera/"
     */
    private fun normalizeFolder(path: String): String =
        path.trim().lowercase().removePrefix("/")

    /**
     * Checks whether file path is under one of the user-selected folders
     */
    private fun isUnderSelectedFolders(
        mediaPath: String,
        selectedFolders: Set<String>
    ): Boolean {
        if (selectedFolders.isEmpty()) return true
        return selectedFolders.any { mediaPath.startsWith(it) }
    }
}

