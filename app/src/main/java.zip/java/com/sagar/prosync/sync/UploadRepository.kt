package com.sagar.prosync.sync

import android.content.Context
import com.sagar.prosync.data.ApiClient
import com.sagar.prosync.data.api.PhotoApi
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

class UploadRepository(private val context: Context) {

    // ✅ SINGLE api instance (no api() calls)
    private val api: PhotoApi =
        ApiClient.create(context).create(PhotoApi::class.java)

    suspend fun upload(item: MediaItem) {

        val sha = HashUtils.sha256(context, item.uri)

        // ✅ call api directly (not api())
        val exists = api.check(
            mapOf(
                "sha256" to sha,
                "file_size" to item.size,
                "media_type" to if (item.isVideo) "video" else "photo"
            )
        ).exists

        if (exists) return

        // ⚠️ NOTE: still using readBytes() (OK for now)
        val input = context.contentResolver.openInputStream(item.uri)
            ?: return

        val bytes = input.use { it.readBytes() }

        val body = bytes.toRequestBody(
            "application/octet-stream".toMediaType()
        )

        val filePart = MultipartBody.Part.createFormData(
            name = "file",
            filename = "upload.bin",
            body = body
        )

        api.upload(
            file = filePart,
            sha256 = sha.toRequestBody("text/plain".toMediaType()),
            relativePath = item.relativePath.toRequestBody("text/plain".toMediaType()),
            mediaType = (if (item.isVideo) "video" else "photo")
                .toRequestBody("text/plain".toMediaType())
        )
    }
}
