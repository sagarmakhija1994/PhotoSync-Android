package com.sagar.prosync.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sagar.prosync.auth.LoginScreen
import com.sagar.prosync.ui.SyncOptionsScreen

object Routes {
    const val LOGIN = "login"
    const val SYNC_OPTIONS = "sync_options"
}

@Composable
fun AppNavGraph(startDestination: String) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Routes.SYNC_OPTIONS) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.SYNC_OPTIONS) {
            SyncOptionsScreen()
        }
    }
}
