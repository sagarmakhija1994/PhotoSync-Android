package com.sagar.prosync.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sagar.prosync.data.SessionStore
import com.sagar.prosync.device.DeviceRegistrationRepository
import com.sagar.prosync.device.DeviceRegistrationResult
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text("PhotoSync Login", style = MaterialTheme.typography.headlineSmall)

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username") }
            )

            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") }
            )

            Spacer(Modifier.height(16.dp))

            if (error != null) {
                Text(error!!, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
            }

            Button(
                enabled = !loading && username.isNotBlank() && password.isNotBlank(),
                onClick = {
                    loading = true
                    error = null

                    scope.launch {
                        val repo = DeviceRegistrationRepository(context)
                        when (repo.register()) {
                            DeviceRegistrationResult.Success ->{
                                onLoginSuccess()
                                // TEMP: assume login success & token saved
                                SessionStore(context).saveToken("TEMP_TOKEN")
                            }

                            DeviceRegistrationResult.Blocked ->
                                error = "This device has been blocked by the server"

                            is DeviceRegistrationResult.Error ->
                                error = "Device registration failed"
                        }
                        loading = false
                    }
                }
            ) {
                Text(if (loading) "Please wait…" else "Login")
            }
        }
    }
}


